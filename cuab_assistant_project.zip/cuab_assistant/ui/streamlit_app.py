# -- This will be replaced by the full UI code block from the user --
# Actual logic from user provided code goes here.
